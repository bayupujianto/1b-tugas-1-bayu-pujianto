#include <iostream>
#include <string>
using namespace std;

int main(){
    int umur;
    string namaLengkap, kelas, hobi, citaCita, npm;

    npm = "2210631170149";
    namaLengkap = "Rizky Fahrureza";
    umur = 19;
    kelas = "1B";
    hobi = "Bertanya";
    citaCita = "Blockchain developer";

    cout << "NPM: " << npm << endl;
    cout << "Nama Lengkap: " << namaLengkap << endl;
    cout << "Umur: " << umur << endl;
    cout << "Kelas: " << kelas << endl;
    cout << "Hobi: " << hobi << endl;
    cout << "Cita-cita: " << citaCita << endl;


    return 0;
}
